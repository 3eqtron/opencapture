#!/bin/bash

# MaarchCapture Installation Script
# This script automates the installation of MaarchCapture PDF import module

# Exit on any error
set -e

# Configuration variables - modify these before running
INSTALL_DIR="/opt/maarch/MaarchCapture"
MAARCH_API_URL="http://localhost/maarch/rest"
MAARCH_API_USER="ws_user"
MAARCH_API_PASSWORD="password"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to display status messages
function echo_status {
    echo -e "${GREEN}[INFO]${NC} $1"
}

# Function to display error messages
function echo_error {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to display warning messages
function echo_warning {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo_error "Please run this script as root or with sudo"
    exit 1
fi

echo_status "Starting MaarchCapture installation..."

# Check if the installation directory already exists
if [ -d "$INSTALL_DIR" ]; then
    echo_warning "Installation directory $INSTALL_DIR already exists"
    read -p "Do you want to overwrite it? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo_status "Installation aborted"
        exit 0
    fi
    echo_status "Removing existing installation..."
    rm -rf "$INSTALL_DIR"
fi

# Create installation directory
echo_status "Creating installation directory..."
mkdir -p "$INSTALL_DIR"

# Extract archive
echo_status "Extracting MaarchCapture files..."
if [ -f "maarchcapture.tar.gz" ]; then
    tar -xzf maarchcapture.tar.gz -C "$INSTALL_DIR"
else
    echo_error "maarchcapture.tar.gz not found in current directory"
    exit 1
fi

# Create required directories
echo_status "Creating required directories..."
mkdir -p "$INSTALL_DIR/files/TEST_IMPORT/backup"
mkdir -p "$INSTALL_DIR/files/TEST_IMPORT/failed"

# Set permissions
echo_status "Setting permissions..."
chown -R www-data:www-data "$INSTALL_DIR"
chmod -R 755 "$INSTALL_DIR"
chmod -R 777 "$INSTALL_DIR/files"

# Configure PDF import script
echo_status "Configuring PDF import script..."
CONFIG_FILE="$INSTALL_DIR/scripts/process_import_pdfs.php"

# Backup original config
cp "$CONFIG_FILE" "$CONFIG_FILE.bak"

# Update configuration
sed -i "s|http://ws_user:securepassword123@localhost/gedmaarch/rest|http://$MAARCH_API_USER:$MAARCH_API_PASSWORD@$MAARCH_API_URL|g" "$CONFIG_FILE"

# Create cron job
echo_status "Setting up cron job for automated processing..."
CRON_JOB="*/5 * * * * cd $INSTALL_DIR && php scripts/process_import_pdfs.php >> /var/log/maarch_import.log 2>&1"
(crontab -l 2>/dev/null || echo "") | grep -v "process_import_pdfs.php" | { cat; echo "$CRON_JOB"; } | crontab -

# Check for required PHP extensions
echo_status "Checking required PHP extensions..."
for ext in curl xml mbstring gd; do
    if php -m | grep -q $ext; then
        echo_status "PHP extension $ext is installed"
    else
        echo_warning "PHP extension $ext is not installed. Installing..."
        apt-get update
        apt-get install -y php-$ext
    fi
done

# Restart web server
echo_status "Restarting web server..."
if systemctl is-active --quiet apache2; then
    systemctl restart apache2
elif systemctl is-active --quiet nginx; then
    systemctl restart nginx
else
    echo_warning "Neither Apache nor Nginx detected. Please restart your web server manually."
fi

echo_status "Installation completed successfully!"
echo_status "MaarchCapture has been installed to $INSTALL_DIR"
echo_status "You can now place PDF files and their XML metadata in $INSTALL_DIR/files/TEST_IMPORT for processing"
echo_status "The import process will run automatically every 5 minutes"
echo_status "To run it manually, use: php $INSTALL_DIR/scripts/process_import_pdfs.php"

exit 0
