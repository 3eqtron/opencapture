﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MaarchBarCodeReader
{

    class Program
    {
        public const int DW_ST_CODE128 = 0x00000001;
        public const int DW_ST_CODE39  = 0x00000002;

        static void Main(string[] args)
        {
            try
            {
                if (args.Length == 0)
                {
                    Console.WriteLine("This program read barcodes");
                    Console.WriteLine("Please enter a path to an image file to read.");
                    Console.WriteLine("Usage: MaarchBarcodeReader <pathToFile> [<bacodetype:C128|C39>]");
                }
                else
                {
                    string sResult = "";
                    BarcodeReaderLib.BarcodeDecoder barcodeDecoder = new BarcodeReaderLib.BarcodeDecoder();
                    
                    barcodeDecoder.LinearFindBarcodes = 50;
                    if (args.Length == 2 && !args[1].Equals(""))
                    {
                        if (args[1].Equals("C128"))
                        {
                            barcodeDecoder.BarcodeTypes = DW_ST_CODE128;
                        }
                        else if (args[1].Equals("C39"))
                        {
                            barcodeDecoder.BarcodeTypes = DW_ST_CODE39;
                        }
                        else
                        {
                            Console.WriteLine("requested barcode type not well formed:" + args[1] + " must be C128 or C39");
                            Console.WriteLine("the engine will recognized barcode with no restriction on the type");
                        }
                    }
                    barcodeDecoder.LinearShowCheckDigit = false;
                    barcodeDecoder.DecodeFile(args[0]);
                    //show results
                    BarcodeReaderLib.BarcodeList BarcodeList = barcodeDecoder.Barcodes;
                    for (int i = 0; i < BarcodeList.length; i++)
                    {
                        BarcodeReaderLib.barcode barcode = BarcodeList.item(i);
                        //sResult += string.Format("{0}\n{1}\n({2},{3}),({4},{5}),({6},{7}),({8},{9})\nPage: {10}\n", barcode.BarcodeType.ToString(), barcode.Text, barcode.x1, barcode.y1, barcode.x2, barcode.y2, barcode.x3, barcode.y3, barcode.x4, barcode.y4, barcode.PageNum);
                        sResult += string.Format("{0}:{1}##", barcode.BarcodeType.ToString(), barcode.Text);
                    }
                    Console.WriteLine(sResult);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
